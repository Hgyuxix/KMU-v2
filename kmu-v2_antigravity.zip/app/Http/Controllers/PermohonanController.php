<?php

namespace App\Http\Controllers;

use App\Models\Layanan;
use App\Models\Permohonan;
use App\Models\DokumenPersyaratan;
use App\Services\NikEncryptionService;
use App\Services\SuratGenerator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PermohonanController extends Controller
{
    public function index(Request $request)
    {
        $query = Permohonan::with('layanan')
            ->where('kelurahan_id', $request->user()->kelurahan_id)
            ->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        $permohonans = $query->paginate(10)->withQueryString();

        $kelurahanId = $request->user()->kelurahan_id;

        $stats = Permohonan::selectRaw("
            COUNT(CASE WHEN status = 'diajukan' THEN 1 END) as diajukan,
            COUNT(CASE WHEN status = 'revisi' THEN 1 END) as revisi,
            COUNT(CASE WHEN status = 'disetujui' THEN 1 END) as disetujui
        ")->where('kelurahan_id', $kelurahanId)->first();

        return view('kelurahan.index', compact('permohonans', 'stats'));
    }

    public function create(Layanan $layanan)
    {
        abort_if(!$layanan->aktif, 404);

        $layanan->load('persyaratans');

        $fields = config('surat.' . $layanan->id, []);

        return view('permohonan.create', compact(
            'layanan',
            'fields'
        ));
    }

    public function store(
        Request $request,
        Layanan $layanan,
        NikEncryptionService $nikEncryptionService
    ) {
        abort_if(!$layanan->aktif, 404);
        abort_if(!$request->user()->kelurahan_id, 403, 'Akun ini belum terhubung ke kelurahan mana pun.');

        $layanan->load('persyaratans');

        $fields = config('surat.' . $layanan->id, []);

        /*
        |--------------------------------------------------------------------------
        | Validasi data utama warga
        |--------------------------------------------------------------------------
        */

        $rules = [
            'nama_lengkap' => [
                'required',
                'string',
                'max:255',
            ],

            'tanggal_lahir' => [
                'required',
                'date',
            ],

            'nik' => [
                'required',
                'digits:16',
            ],

            'rt' => [
                'required',
                'string',
                'max:3',
            ],

            'rw' => [
                'required',
                'string',
                'max:3',
            ],
        ];

        /*
        |--------------------------------------------------------------------------
        | Validasi field tambahan surat
        |--------------------------------------------------------------------------
        */

        foreach ($fields as $field => $label) {
            $rules['data_surat.' . $field] = [
                'required',
                'string',
                'max:1000',
            ];
            if ($layanan->id == 1) {
                $rules['data_surat.jenis_kelamin'] = [
                    'required',
                    'in:Laki-laki,Perempuan',
                ];

                $rules['data_surat.agama'] = [
                    'required',
                    'in:Islam,Kristen,Katolik,Hindu,Buddha,Konghucu',
                ];
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Validasi dokumen persyaratan
        |--------------------------------------------------------------------------
        */

        foreach ($layanan->persyaratans as $persyaratan) {

            $fieldName = 'persyaratan.' . $persyaratan->id;

            $extensions = collect(
                explode(',', $persyaratan->tipe_file)
            )
                ->map(fn ($item) => trim($item))
                ->filter()
                ->values()
                ->implode(',');

            $rules[$fieldName] = [
                $persyaratan->wajib ? 'required' : 'nullable',
                'file',
                'mimes:' . $extensions,
                'max:' . $persyaratan->maks_size,
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Jalankan validasi
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate($rules);

        /*
        |--------------------------------------------------------------------------
        | Simpan permohonan
        |--------------------------------------------------------------------------
        */

        $dataSurat = $validated['data_surat'] ?? [];

        $permohonan = Permohonan::create([
            'layanan_id' => $layanan->id,
            'kelurahan_id' => $request->user()->kelurahan_id,
            'dibuat_oleh' => $request->user()->id,
            'nama_lengkap' => $validated['nama_lengkap'],
            'tanggal_lahir' => $validated['tanggal_lahir'],
            'nik' => $nikEncryptionService->encrypt(
                $validated['nik']
            ),
            'rt' => $validated['rt'],
            'rw' => $validated['rw'],
            'data_surat' => $dataSurat,
            'status' => 'diajukan',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Simpan dokumen persyaratan
        |--------------------------------------------------------------------------
        */

        foreach ($layanan->persyaratans as $persyaratan) {

            $file = $request->file(
                'persyaratan.' . $persyaratan->id
            );

            if ($file) {

                $path = $file->store(
                    'persyaratan/' . $permohonan->id,
                    'local'
                );

                $permohonan->dokumenPersyaratans()->create([
                    'persyaratan_id' => $persyaratan->id,
                    'file_path' => $path,
                    'file_original_name' => $file->getClientOriginalName(),
                ]);
            }
        }

        return redirect()
            ->route('permohonan.preview', $permohonan)
            ->with('success', 'Surat berhasil dibuat.');
    }

    /*
    |--------------------------------------------------------------------------
    | Preview Surat
    |--------------------------------------------------------------------------
    */

    public function preview(
        Permohonan $permohonan,
        SuratGenerator $suratGenerator
    ) {
        $permohonan->load([
            'layanan',
            'dokumenPersyaratans',
        ]);

        $surat = $suratGenerator->generate($permohonan);

        return view('permohonan.preview', compact(
            'permohonan',
            'surat'
        ));
    }

    public function lihatDokumen(DokumenPersyaratan $dokumen)
    {
        $permohonan = $dokumen->permohonan;
        $user = request()->user();

        abort_if(
            $user->isKelurahan() && $permohonan->kelurahan_id !== $user->kelurahan_id,
            403
        );

        abort_unless(Storage::disk('local')->exists($dokumen->file_path), 404);

        return Storage::disk('local')->response(
            $dokumen->file_path,
            $dokumen->file_original_name
        );
    }

    public function editRevisi(Request $request, Permohonan $permohonan)
    {
        $user = $request->user();

        abort_unless(
            $user->isKelurahan() &&
            $permohonan->kelurahan_id === $user->kelurahan_id,
            403
        );

        abort_unless(
            $permohonan->status === 'revisi',
            404
        );

        $permohonan->load([
            'layanan.persyaratans',
            'dokumenPersyaratans.persyaratan',
        ]);

        $layanan = $permohonan->layanan;

        $fields = config('surat.' . $permohonan->layanan_id, []);

        return view('permohonan.edit', compact(
            'permohonan',
            'layanan',
            'fields'
        ));
    }

    public function updateRevisi(
        Request $request,
        Permohonan $permohonan,
        NikEncryptionService $nikEncryptionService
    ) {
        $user = $request->user();

        abort_unless(
            $user->isKelurahan() &&
            $permohonan->kelurahan_id === $user->kelurahan_id,
            403
        );

        abort_unless(
            $permohonan->status === 'revisi',
            404
        );

        $layanan = $permohonan->layanan()->with('persyaratans')->first();

        $fields = config('surat.' . $layanan->id, []);

        $rules = [
            'nama_lengkap' => ['required', 'string', 'max:255'],
            'tanggal_lahir' => ['required', 'date'],
            'nik' => ['required', 'digits:16'],
            'rt' => ['required', 'string', 'max:3'],
            'rw' => ['required', 'string', 'max:3'],
        ];

        foreach ($fields as $field => $config) {
            $type = $config['type'] ?? 'text';

            if ($type === 'select' && isset($config['options'])) {
                $rules['data_surat.' . $field] = [
                    'required',
                    'string',
                    'in:' . implode(',', $config['options']),
                ];
            } else {
                $rules['data_surat.' . $field] = [
                    'required',
                    'string',
                    'max:1000',
                ];
            }
        }

        foreach ($layanan->persyaratans as $persyaratan) {

            $existing = $permohonan->dokumenPersyaratans()
                ->where('persyaratan_id', $persyaratan->id)
                ->first();

            $needsNewFile = $existing &&
                $existing->status === 'tidak_sesuai';

            $isMissingRequired = !$existing && $persyaratan->wajib;

            $fieldName = 'persyaratan.' . $persyaratan->id;

            $extensions = collect(
                explode(',', $persyaratan->tipe_file)
            )
                ->map(fn ($item) => trim($item))
                ->filter()
                ->values()
                ->implode(',');

            $rules[$fieldName] = [
                $needsNewFile || !$isMissingRequired
                    ? 'required'
                    : 'nullable',
                'file',
                'mimes:' . $extensions,
                'max:' . $persyaratan->maks_size,
            ];
        }

        $validated = $request->validate($rules);

        $dataSurat = $validated['data_surat'] ?? [];

        $updateData = [
            'nama_lengkap' => $validated['nama_lengkap'],
            'tanggal_lahir' => $validated['tanggal_lahir'],
            'rt' => $validated['rt'],
            'rw' => $validated['rw'],
            'data_surat' => $dataSurat,
            'status' => 'diajukan',
            'catatan_revisi' => null,
            'diproses_oleh' => null,
            'diproses_at' => null,
            'alasan_penolakan' => null,
            'nomor_surat' => null,
        ];

        if ($request->filled('nik')) {
            $updateData['nik'] = $nikEncryptionService->encrypt(
                $validated['nik']
            );
        }

        $permohonan->update($updateData);

        foreach ($layanan->persyaratans as $persyaratan) {

            $file = $request->file(
                'persyaratan.' . $persyaratan->id
            );

            if (!$file) {
                continue;
            }

            $existing = $permohonan->dokumenPersyaratans()
                ->where('persyaratan_id', $persyaratan->id)
                ->first();

            if ($existing) {
                Storage::disk('local')->delete($existing->file_path);

                $existing->update([
                    'file_path' => $file->store(
                        'persyaratan/' . $permohonan->id,
                        'local'
                    ),
                    'file_original_name' => $file->getClientOriginalName(),
                    'status' => 'belum_dicek',
                ]);
            } else {
                $permohonan->dokumenPersyaratans()->create([
                    'persyaratan_id' => $persyaratan->id,
                    'file_path' => $file->store(
                        'persyaratan/' . $permohonan->id,
                        'local'
                    ),
                    'file_original_name' => $file->getClientOriginalName(),
                    'status' => 'belum_dicek',
                ]);
            }
        }

        return redirect()
            ->route('kelurahan.index')
            ->with('success', 'Pengajuan berhasil diperbaiki dan dikirim ulang ke Kecamatan.');
    }
}
