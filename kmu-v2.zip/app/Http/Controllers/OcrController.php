<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Symfony\Component\Process\Process;

class OcrController extends Controller
{
    /**
     * Terima 1 foto KTP, jalankan OCR via script Python,
     * balikin hasil parsing sebagai JSON buat pre-fill form.
     *
     * PENTING: ini cuma bantu isi form otomatis. Staff kelurahan
     * TETAP wajib review manual sebelum submit, terutama NIK -
     * makanya kita gak langsung simpan apapun ke database di sini.
     */
    public function scanKtp(Request $request)
    {
        $request->validate([
            'foto_ktp' => ['required', 'image', 'mimes:jpg,jpeg,png', 'max:8192'],
        ]);

        $pythonBin = config('services.ocr.python_bin', 'python3');

        // ==========================================
        // PRE-FLIGHT CHECK
        // ==========================================
        // Ngecek dulu python & semua modul yang dibutuhkan ada,
        // SEBELUM buang waktu upload+proses foto. Kalau gagal di
        // sini, pesannya jelas: python mana yang dipake & modul
        // apa yang belum ke-install - gak perlu bongkar log lagi.
        $check = new Process([
            $pythonBin,
            '-c',
            'import cv2, pytesseract, numpy; print("OK")',
        ]);
        $check->setTimeout(15);
        $check->run();

        if (!$check->isSuccessful()) {
            Log::error('OCR KTP: pre-flight check gagal', [
                'python_bin' => $pythonBin,
                'error_output' => $check->getErrorOutput(),
            ]);

            return response()->json([
                'success' => false,
                'message' => "Python/library OCR belum siap di server. "
                    . "python_bin yang dipakai: \"{$pythonBin}\". "
                    . 'Detail: ' . trim($check->getErrorOutput()),
            ], 422);
        }

        $tempDir = storage_path('app/tmp-ocr');
        if (!is_dir($tempDir)) {
            mkdir($tempDir, 0775, true);
        }

        $filename = Str::random(20) . '.' . $request->file('foto_ktp')->extension();
        $tempPath = $tempDir . DIRECTORY_SEPARATOR . $filename;

        $request->file('foto_ktp')->move($tempDir, $filename);

        try {
            $scriptPath = base_path('ocr/ocr_ktp_v3.py');

            $process = new Process([
                $pythonBin,
                $scriptPath,
                $tempPath,
            ]);

            if ($tesseractCmd = config('services.ocr.tesseract_cmd')) {
                $process->setEnv(['TESSERACT_CMD' => $tesseractCmd]);
            }

            $process->setTimeout(30);
            $process->run();

            if (!$process->isSuccessful()) {
                Log::error('OCR KTP gagal dijalankan', [
                    'python_bin' => $pythonBin,
                    'command' => $process->getCommandLine(),
                    'error_output' => $process->getErrorOutput(),
                ]);

                return response()->json([
                    'success' => false,
                    'message' => 'Gagal memproses foto KTP. Detail: '
                        . trim($process->getErrorOutput()),
                ], 422);
            }

            $output = trim($process->getOutput());
            $result = json_decode($output, true);

            if (!is_array($result)) {
                Log::error('OCR KTP: output tidak valid', ['raw_output' => $output]);

                return response()->json([
                    'success' => false,
                    'message' => 'Hasil OCR tidak terbaca. Silakan isi manual.',
                ], 422);
            }

            return response()->json($result);

        } finally {
            // Foto KTP mentah gak perlu disimpen permanen -
            // cukup dipakai sekali buat OCR terus dihapus.
            if (file_exists($tempPath)) {
                unlink($tempPath);
            }
        }
    }
}
