<?php

namespace App\Http\Controllers;

use App\Models\Layanan;
use App\Models\Kelurahan;
use App\Models\Permohonan;
use App\Models\DokumenPersyaratan;
use App\Services\SuratGenerator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $query = Permohonan::with('layanan','kelurahan')->latest();

        if ($request->filled('q')) {
            $q = trim($request->input('q'));
            $query->where(function ($builder) use ($q) {
                $builder->where('nama_lengkap', 'like', "%{$q}%")
                    ->orWhere('id', is_numeric($q) ? (int) $q : -1);
            });
        }

        if ($request->filled('layanan_id')) {
            $query->where('layanan_id', $request->integer('layanan_id'));
        }

        if ($request->filled('kelurahan_id')) {
            $query->where('kelurahan_id', $request->integer('kelurahan_id'));
        }

        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        $permohonans = $query->paginate(10)->withQueryString();

        $stats = [
            'total' => Permohonan::count(),
            'diajukan' => Permohonan::where('status', 'diajukan')->count(),
            'revisi' => Permohonan::where('status', 'revisi')->count(),
            'disetujui' => Permohonan::where('status', 'disetujui')->count(),
            'selesai' => Permohonan::where('status', 'selesai')->count(),
        ];

        $layanans = Layanan::where('aktif', true)->orderBy('id')->get(['id', 'nama']);

        $kelurahans = Kelurahan::orderBy('nama')->get(['id', 'nama']);

        return view('dashboard.index', compact('permohonans', 'stats', 'layanans', 'kelurahans'));
    }

    public function show(Permohonan $permohonan)
    {
        $permohonan->load(['layanan.persyaratans', 'dokumenPersyaratans.persyaratan']);
        return view('dashboard.show', compact('permohonan'));
    }

    public function approve(Request $request, Permohonan $permohonan)
    {
        abort_if($permohonan->status === 'disetujui', 409, 'Pengajuan ini sudah disetujui sebelumnya.');

        $permohonan->update([
            'status' => 'disetujui',
            'diproses_oleh' => $request->user()->id,
            'diproses_at' => now(),
            'nomor_surat' => $permohonan->nomor_surat
                ?? SuratGenerator::buatNomorSurat($permohonan),
        ]);

        return back()->with('success', 'Pengajuan disetujui, surat resmi diterbitkan.');
    }

    /**
     * Kecamatan buka/liat file dokumen persyaratan yang diupload kelurahan.
     */
    public function lihatDokumen(DokumenPersyaratan $dokumen)
    {
        abort_unless(Storage::disk('local')->exists($dokumen->file_path), 404);

        return Storage::disk('local')->response(
            $dokumen->file_path,
            $dokumen->file_original_name
        );
    }

    /**
     * Kecamatan tandain 1 dokumen sesuai / tidak sesuai.
     */
    public function updateDokumenStatus(Request $request, DokumenPersyaratan $dokumen)
    {
        $data = $request->validate([
            'status' => ['required', 'in:sesuai,tidak_sesuai'],
        ]);

        $dokumen->update(['status' => $data['status']]);

        return back()->with('success', 'Status dokumen diperbarui.');
    }

    public function requestRevision(Request $request, Permohonan $permohonan)
    {
        $request->validate([
            'catatan_revisi' => ['required', 'string', 'max:2000'],
        ]);

        $permohonan->update([
            'status' => 'revisi',
            'catatan_revisi' => $request->catatan_revisi,
        ]);

        return redirect()
            ->route('dashboard.pengajuan.show', $permohonan)
            ->with('success', 'Pengajuan dikembalikan untuk revisi.');
    }
}
