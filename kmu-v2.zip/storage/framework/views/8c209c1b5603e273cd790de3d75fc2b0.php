<!DOCTYPE html>
<html lang="id">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo e($layanan->nama); ?> — Pelayanan Administrasi</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/kmu.css')); ?>">
    </head>

    <body>
        <nav class="kmu-nav">
            <a class="kmu-brand" href="<?php echo e(route('layanan.index')); ?>">
                <img src="<?php echo e(asset('assets/logo-kota-magelang.jpg')); ?>" alt="Logo Kota Magelang">
                <span>Pelayanan Administrasi<br>Kecamatan Magelang Utara</span>
            </a>
            <div class="kmu-navlinks">
                <a href="<?php echo e(route('layanan.index')); ?>">Beranda</a>
                <a class="active" href="<?php echo e(route('layanan.index')); ?>">Layanan</a>
                <a href="<?php echo e(route('dashboard')); ?>">Dashboard Pelayanan</a>
            </div>
        </nav>

        <main class="detail-wrap">
            <a class="back" href="<?php echo e(route('layanan.index')); ?>">← Kembali ke layanan</a>
            <section class="panel">
                <div class="eyebrow">Layanan <?php echo e($layanan->id); ?></div>
                <h1><?php echo e($layanan->nama); ?></h1>
                <p class="lead"><?php echo e($layanan->deskripsi); ?></p>
                <?php if($layanan->tte): ?>
                <span class="badge">✓ Diproses dengan Tanda Tangan Elektronik</span>
                <?php endif; ?>
                <h2 style="font-size:18px;margin:24px 0 8px">Persyaratan</h2>
                <div class="req-list">
                    <?php $__currentLoopData = $layanan->persyaratans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $persyaratan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="req">
                        <div class="req-title"><?php echo e($index + 1); ?>. <?php echo e($persyaratan->nama); ?>

                            <?php if($persyaratan->wajib): ?>
                            <span style="color:#e11d48">*</span>
                            <?php endif; ?>
                        </div>
                        <div class="req-meta">
                            <?php echo e($persyaratan->wajib ? 'Wajib' : 'Opsional'); ?> · <?php echo e(strtoupper(str_replace(',', ', ', $persyaratan->tipe_file))); ?> · Maks. <?php echo e($persyaratan->maks_size >= 1024 ? ($persyaratan->maks_size / 1024).' MB' : $persyaratan->maks_size.' KB'); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="primary-btn" href="<?php echo e(route('permohonan.create', $layanan)); ?>">Lanjutkan Pengajuan →</a>
            </section>
        </main>
    </body>
</html>
<?php /**PATH D:\MAGYANGGG\kmu-v2\resources\views/layanan/show.blade.php ENDPATH**/ ?>