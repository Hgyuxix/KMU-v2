<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Saya — Kelurahan</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/kmu.css')); ?>">
</head>

<body>
    <nav class="kmu-nav">
        <a class="kmu-brand" href="<?php echo e(route('layanan.index')); ?>">
            <img src="<?php echo e(asset('assets/logo-kota-magelang.jpg')); ?>" alt="Logo Kota Magelang">
            <span>Pelayanan Administrasi<br>Kecamatan Magelang Utara</span>
        </a>

        <div class="kmu-navlinks">
            <a href="<?php echo e(route('layanan.index')); ?>">Beranda</a>
            <a class="active" href="<?php echo e(route('kelurahan.index')); ?>">Pengajuan Saya</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline">
                <?php echo csrf_field(); ?>
                <button class="nav-logout" type="submit">Keluar</button>
            </form>
        </div>
    </nav>

    <?php if(session('success')): ?><div class="alert success" style="max-width:1100px;margin:20px auto 0"><?php echo e(session('success')); ?></div><?php endif; ?>

    <main class="dashboard-wrap">
        <div class="dashboard-head">
            <div>
                <div class="eyebrow">Kelurahan</div>
                <h1>Pengajuan Saya</h1>
                <p>Daftar surat yang sudah diajukan ke Kecamatan dari kelurahan ini.</p>
            </div>
            <a class="primary-btn" href="<?php echo e(route('layanan.index')); ?>">+ Pengajuan Baru</a>
        </div>

        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-label">Menunggu ACC</div>
                <div class="stat-value"><?php echo e($stats['diajukan']); ?></div>
                <div class="stat-note">Belum diproses kecamatan</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Perlu Revisi</div>
                <div class="stat-value"><?php echo e($stats['revisi']); ?></div>
                <div class="stat-note">Menunggu perbaikan pengajuan</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Disetujui</div>
                <div class="stat-value"><?php echo e($stats['disetujui']); ?></div>
                <div class="stat-note">Surat resmi terbit</div>
            </div>

        </div>

        <section class="dashboard-panel">
            <div class="panel-title-row">
                <div><h2>Riwayat Pengajuan</h2><p><?php echo e($permohonans->total()); ?> data ditemukan.</p></div>
            </div>

            <form class="filter-bar" method="GET" action="<?php echo e(route('kelurahan.index')); ?>" style="grid-template-columns:minmax(180px,1fr) auto">
                <div>
                    <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="">Semua status</option>
                            <option value="diajukan" <?php if(request('status') === 'diajukan'): echo 'selected'; endif; ?>>Diajukan</option>
                            <option value="disetujui" <?php if(request('status') === 'disetujui'): echo 'selected'; endif; ?>>Disetujui</option>
                            <option value="revisi" <?php if(request('status') === 'revisi'): echo 'selected'; endif; ?>>Revisi</option>
                        </select>
                </div>
                <div class="filter-actions">
                    <button class="primary-btn" type="submit">Terapkan</button>
                    <a class="secondary-btn" href="<?php echo e(route('kelurahan.index')); ?>">Reset</a>
                </div>
            </form>

            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Warga</th>
                            <th>Layanan</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong>#<?php echo e(str_pad($permohonan->id, 4, '0', STR_PAD_LEFT)); ?></strong>
                                </td>
                                <td>
                                    <div class="table-main"><?php echo e($permohonan->nama_lengkap); ?></div>
                                </td>
                                <td><?php echo e($permohonan->layanan->nama); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo e($permohonan->status); ?>">
                                        <?php echo e(ucfirst($permohonan->status)); ?>

                                    </span>
                                    <?php if($permohonan->status === 'revisi'): ?>
                                        <div class="alert alert-warning">
                                            <strong>Pengajuan perlu direvisi</strong>

                                            <p>
                                                <?php echo e($permohonan->catatan_revisi); ?>

                                            </p>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($permohonan->created_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <?php if($permohonan->status === 'revisi'): ?>
                                        <a
                                            class="table-link"
                                            href="<?php echo e(route('kelurahan.pengajuan.revisi', $permohonan)); ?>"
                                        >
                                            Perbaiki →
                                        </a>

                                    <?php else: ?>
                                        <a
                                            class="table-link"
                                            href="<?php echo e(route('permohonan.preview', $permohonan)); ?>"
                                        >
                                            Detail →
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <div class="empty-icon">⌕</div>
                                        <strong>Belum ada pengajuan</strong>
                                        <span>Klik "+ Pengajuan Baru" buat mulai.</span>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($permohonans->hasPages()): ?>
                <div class="pagination-wrap"><?php echo e($permohonans->links()); ?></div>
            <?php endif; ?>
        </section>
    </main>
    <footer class="footer">Kecamatan Magelang Utara · Pemerintah Kota Magelang</footer>
</body>
</html>
<?php /**PATH D:\MAGYANGGG\kmu-v2\resources\views/kelurahan/index.blade.php ENDPATH**/ ?>