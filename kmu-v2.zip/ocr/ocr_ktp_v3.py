import json
import os
import re
import sys
from pathlib import Path

import cv2
import numpy as np
import pytesseract


BASE_DIR = Path(__file__).resolve().parent


# =========================================================
# TESSERACT
# =========================================================

# Path tesseract.exe bisa diatur lewat environment variable TESSERACT_CMD
# (dikirim dari Laravel, lihat config/services.php -> OcrController).
# Kalau gak diset, pytesseract coba cari otomatis di PATH sistem.
_tesseract_cmd = os.environ.get("TESSERACT_CMD")
if _tesseract_cmd:
    pytesseract.pytesseract.tesseract_cmd = _tesseract_cmd


# =========================================================
# STEP 1 - DESKEW & CROP KARTU
# =========================================================
#
# Foto KTP yang diupload warga hampir gak pernah lurus/center
# sempurna. Bagian ini nyari 4 sudut kartu (kontur terbesar)
# dan "meluruskan" perspektifnya sebelum OCR jalan.
#
# Kalau kartu gak kedeteksi jelas (background rame, dst),
# fungsi ini fallback ke gambar asli - gak bikin error.

def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")

    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]

    return rect


def deskew_and_crop(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 50, 150)
    edges = cv2.dilate(edges, np.ones((5, 5), np.uint8), iterations=1)

    contours, _ = cv2.findContours(
        edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    if not contours:
        return image, False

    largest = max(contours, key=cv2.contourArea)

    # Kalau kontur terbesar terlalu kecil dibanding foto,
    # kemungkinan itu bukan kartu KTP - skip transform.
    image_area = image.shape[0] * image.shape[1]
    if cv2.contourArea(largest) < image_area * 0.2:
        return image, False

    peri = cv2.arcLength(largest, True)
    approx = cv2.approxPolyDP(largest, 0.02 * peri, True)

    if len(approx) != 4:
        return image, False

    pts = approx.reshape(4, 2).astype("float32")
    (tl, tr, br, bl) = order_points(pts)

    width_a = np.linalg.norm(br - bl)
    width_b = np.linalg.norm(tr - tl)
    max_width = int(max(width_a, width_b))

    height_a = np.linalg.norm(tr - br)
    height_b = np.linalg.norm(tl - bl)
    max_height = int(max(height_a, height_b))

    if max_width < 200 or max_height < 100:
        return image, False

    dst = np.array([
        [0, 0],
        [max_width - 1, 0],
        [max_width - 1, max_height - 1],
        [0, max_height - 1],
    ], dtype="float32")

    matrix = cv2.getPerspectiveTransform(
        order_points(pts), dst
    )

    warped = cv2.warpPerspective(image, matrix, (max_width, max_height))

    return warped, True


# =========================================================
# STEP 2 - IMAGE PREPROCESSING
# =========================================================

def preprocess_image(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    gray = cv2.resize(
        gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC
    )

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)

    # Adaptive threshold lebih tajam buat OCR dibanding blur biasa -
    # blur justru bisa melembutkan tepi karakter yang penting.
    gray = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31, 15
    )

    return gray


# =========================================================
# STEP 3 - OCR JADI BARIS
# =========================================================


def cluster_tokens_into_lines(tokens, y_tolerance_ratio=0.6):
    """
    Kelompokin token individual jadi "baris" berdasarkan kedekatan
    posisi vertikal token itu sendiri - BUKAN pake block/par/line
    bawaan Tesseract (itu asumsi structured single-block, kurang
    cocok buat KTP yang visualnya rame: foto, hologram, background
    bertekstur bikin Tesseract sering salah nebak batas baris).
    """
    if not tokens:
        return []

    sorted_tokens = sorted(tokens, key=lambda t: t["top"])

    lines = []
    current_line = [sorted_tokens[0]]
    current_top = sorted_tokens[0]["top"]
    current_height = sorted_tokens[0]["height"] or 20

    for token in sorted_tokens[1:]:
        tolerance = current_height * y_tolerance_ratio
        if abs(token["top"] - current_top) <= tolerance:
            current_line.append(token)
        else:
            lines.append(current_line)
            current_line = [token]
            current_top = token["top"]
            current_height = token["height"] or 20

    lines.append(current_line)

    result = []
    for line_tokens in lines:
        words_sorted = sorted(line_tokens, key=lambda w: w["left"])
        text = " ".join(w["text"] for w in words_sorted)
        result.append({"text": text, "words": words_sorted})

    return result


def get_ocr_lines(image):
    langs_to_try = ["ind+eng", "ind", "eng"]

    data = None
    used_lang = None

    for lang in langs_to_try:
        try:
            data = pytesseract.image_to_data(
                image,
                lang=lang,
                config="--psm 11",
                output_type=pytesseract.Output.DICT,
            )
            used_lang = lang
            break
        except pytesseract.TesseractError:
            continue

    if data is None:
        data = pytesseract.image_to_data(
            image, config="--psm 11", output_type=pytesseract.Output.DICT
        )
        used_lang = "default"

    tokens = []

    for i in range(len(data["text"])):
        text = data["text"][i].strip()

        if not text:
            continue

        try:
            conf = float(data["conf"][i])
        except (ValueError, TypeError):
            conf = -1

        tokens.append({
            "text": text,
            "left": data["left"][i],
            "top": data["top"][i],
            "width": data["width"][i],
            "height": data["height"][i],
            "conf": conf,
        })

    ordered_lines = cluster_tokens_into_lines(tokens)

    return ordered_lines, used_lang


# =========================================================
# STEP 4 - EKSTRAKSI RELATIF-KE-LABEL
# =========================================================
#
# Alih-alih pakai koordinat pixel absolut (yang gagal kalau
# posisi/scan berbeda dikit), kita cari baris yang mengandung
# LABEL yang selalu ada di setiap KTP ("NIK", "Nama", dst),
# lalu ambil teks SISA baris itu sebagai nilainya.

LABEL_PATTERNS = {
    "nik": r"NIK",
    "nama": r"Nama\b",
    "ttl": r"Tempat\s*/?\.?\s*Tgl\.?\s*Lahir",
    "jenis_kelamin": r"Jenis\s*Kelamin",
    "gol_darah": r"Gol\.?\s*Darah",
    "alamat": r"^\W*Alamat\b",
    "rt_rw": r"RT\s*/?\s*RW",
    "kel_desa": r"Kel\s*/?\s*Desa",
    "kecamatan": r"Kecamatan",
    "agama": r"Agama",
    "status_kawin": r"Status\s*Perkawinan",
    "pekerjaan": r"Pekerjaan",
    "kewarganegaraan": r"Kewarganegaraan",
    "berlaku": r"Berlaku\s*Hingga",
}

# Dipakai buat motong "sisa baris" kalau ada label lain nyempil
# di baris yang sama (misal "Jenis Kelamin: LAKI-LAKI Gol.Darah: O").
OTHER_LABELS_INLINE = r"(Gol\.?\s*Darah|Jenis\s*Kelamin|RT\s*/?\s*RW)"


def find_line_for_label(lines, pattern):
    for line in lines:
        match = re.search(pattern, line["text"], re.IGNORECASE)
        if match:
            return line, match

    return None, None


def extract_value(lines, label_key):
    pattern = LABEL_PATTERNS[label_key]
    line, match = find_line_for_label(lines, pattern)

    if not line:
        return ""

    remainder = line["text"][match.end():]
    remainder = re.sub(r"^[\s:.\-_]+", "", remainder)

    cut = re.search(OTHER_LABELS_INLINE, remainder, re.IGNORECASE)
    if cut:
        remainder = remainder[:cut.start()]

    return remainder.strip(" :.-")


# =========================================================
# FIELD-FIELD SPESIFIK
# =========================================================

def extract_nik(lines):
    raw = extract_value(lines, "nik")
    cleaned = re.sub(r"\D", "", raw)

    digit_count = len(cleaned)
    is_valid = digit_count == 16

    return {
        "raw": raw,
        "cleaned": cleaned,
        "digit_count": digit_count,
        "is_valid": is_valid,
        "needs_review": not is_valid,
    }


def extract_ttl(lines):
    text = extract_value(lines, "ttl")

    match = re.search(
        r"([A-Za-z .'-]+),?\s*"
        r"(\d{1,2})[-/]"
        r"(\d{1,2})[-/]"
        r"(\d{4})",
        text
    )

    if not match:
        return {"tempat_lahir": "", "tanggal_lahir": ""}

    tempat = match.group(1).strip(" ,")

    tanggal = (
        f"{match.group(4)}-"
        f"{match.group(3).zfill(2)}-"
        f"{match.group(2).zfill(2)}"
    )

    return {"tempat_lahir": tempat, "tanggal_lahir": tanggal}


def extract_rt_rw(lines):
    text = extract_value(lines, "rt_rw")

    match = re.search(r"(\d{1,3})\s*/\s*(\d{1,3})", text)

    if not match:
        return {"rt": "", "rw": ""}

    return {
        "rt": match.group(1).zfill(3),
        "rw": match.group(2).zfill(3),
    }


def extract_gender(lines):
    text = extract_value(lines, "jenis_kelamin").upper()

    if "LAKI" in text:
        return "Laki-laki"

    if "PEREMPUAN" in text:
        return "Perempuan"

    return ""


def extract_status_kawin(lines):
    text = extract_value(lines, "status_kawin").upper()

    if "BELUM" in text and "KAWIN" in text:
        return "Belum Kawin"

    if "CERAI" in text and "MATI" in text:
        return "Cerai Mati"

    if "CERAI" in text and "HIDUP" in text:
        return "Cerai Hidup"

    if "KAWIN" in text:
        return "Kawin"

    return ""


def extract_agama(lines):
    text = extract_value(lines, "agama").upper()

    agama_map = {
        "ISLAM": "Islam",
        "KRISTEN": "Kristen",
        "KATOLIK": "Katolik",
        "HINDU": "Hindu",
        "BUDDHA": "Buddha",
        "KONGHUCU": "Konghucu",
    }

    for key, value in agama_map.items():
        if key in text:
            return value

    return ""


def extract_kewarganegaraan(lines):
    text = extract_value(lines, "kewarganegaraan").upper()

    if "WNI" in text:
        return "WNI"

    if "WNA" in text:
        return "WNA"

    return ""


def extract_pekerjaan(lines):
    text = extract_value(lines, "pekerjaan")
    text = re.sub(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{4}\b", "", text)

    return text.strip(" :-")


# =========================================================
# PARSE UTAMA
# =========================================================

def parse_ktp(lines):
    nik = extract_nik(lines)
    ttl = extract_ttl(lines)
    rt_rw = extract_rt_rw(lines)

    data = {
        "nik": nik["cleaned"],
        "nama_lengkap": extract_value(lines, "nama"),
        "tempat_lahir": ttl["tempat_lahir"],
        "tanggal_lahir": ttl["tanggal_lahir"],
        "jenis_kelamin": extract_gender(lines),
        "alamat": extract_value(lines, "alamat"),
        "rt": rt_rw["rt"],
        "rw": rt_rw["rw"],
        "kelurahan": extract_value(lines, "kel_desa"),
        "kecamatan": extract_value(lines, "kecamatan"),
        "agama": extract_agama(lines),
        "status_perkawinan": extract_status_kawin(lines),
        "pekerjaan": extract_pekerjaan(lines),
        "kewarganegaraan": extract_kewarganegaraan(lines),
    }

    validation = {
        "nik_raw": nik["raw"],
        "nik_cleaned": nik["cleaned"],
        "nik_digits_found": nik["digit_count"],
        "nik_valid": nik["is_valid"],
        "nik_needs_review": nik["needs_review"],
        "name_found": bool(data["nama_lengkap"]),
        "ttl_found": bool(data["tanggal_lahir"]),
        "address_found": bool(data["alamat"]),
        "rtrw_found": bool(data["rt"] and data["rw"]),
    }

    return data, validation


# =========================================================
# MAIN
# =========================================================

def main():
    if len(sys.argv) < 2:
        print("Usage:\npy ocr_ktp_v3.py <path_gambar>")
        sys.exit(1)

    image_path = Path(sys.argv[1])

    if not image_path.exists():
        print(f"ERROR: file tidak ditemukan: {image_path}")
        sys.exit(1)

    image = cv2.imread(str(image_path))

    if image is None:
        print("ERROR: gambar gagal dibaca.")
        sys.exit(1)

    cropped, was_deskewed = deskew_and_crop(image)
    processed = preprocess_image(cropped)
    lines, used_lang = get_ocr_lines(processed)
    data, validation = parse_ktp(lines)

    output = {
        "success": validation["name_found"] and validation["nik_valid"],
        "data": data,
        "validation": validation,
        "meta": {
            "deskewed": was_deskewed,
            "ocr_lang": used_lang,
            "lines_found": len(lines),
        },
    }

    output_file = BASE_DIR / "hasil_ktp_v3.json"
    output_file.write_text(
        json.dumps(output, indent=4, ensure_ascii=False),
        encoding="utf-8"
    )

    # PENTING: stdout HARUS berisi JSON murni doang, soalnya ini
    # yang langsung di-parse sama Laravel (json_decode). Info
    # tambahan/debug dikirim ke stderr, bukan stdout.
    print(json.dumps(output, ensure_ascii=False))
    print(f"Output JSON: {output_file}", file=sys.stderr)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
